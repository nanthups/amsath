<!-- page content -->
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper settingPage">
  <!-- Main content -->
  <section class="content">
   <h3 class="box-title">About Us</h3>
   <!-- Default box -->
   <div class="box box-success card">
    <div class="box-body">
      <div class="row">
        <div class="col-lg-12">
          <div class="col-md-6 col-md-offset-1 aboutshift">
            <p>About on new Project</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /.box-body -->
</div>
<!-- /.box -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->